/*
$Header: /var/lib/cvsd/var/lib/cvsd/VulnApp/Default.aspx.cs,v 1.2 2011/02/12 14:24:13 timb Exp $

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
* Neither the name of the Nth Dimension nor the names of its contributors may
be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

(c) Tim Brown, 2011
<mailto:timb@nth-dimension.org.uk>
<http://www.nth-dimension.org.uk/> / <http://www.machine.org.uk/>
*/

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace VulnApp
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class Default : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label WelcomeLabel;
		protected System.Web.UI.WebControls.TextBox UsernameTextBox;
		protected System.Web.UI.WebControls.TextBox PasswordTextBox;
		protected System.Web.UI.WebControls.Label UsernameLabel;
		protected System.Data.SqlClient.SqlConnection SQLConnection;
		protected System.Web.UI.WebControls.Button LoginButton;
		protected System.Web.UI.WebControls.Label ErrorLabel;
		protected System.Web.UI.WebControls.Label PasswordLabel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Request.QueryString["error"] != null)
			{
				this.ErrorLabel.Text = Request.QueryString["error"];
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.SQLConnection = new System.Data.SqlClient.SqlConnection();
			this.LoginButton.Click += new System.EventHandler(this.LoginButton_Click);
			// 
			// SQLConnection
			// 
			this.SQLConnection.ConnectionString = "workstation id=EREBOS;packet size=4096;user id=vulnapp;data source=localhost;pers" +
				"ist security info=True;initial catalog=vulndb;password=vulnapp;Max Pool Size=1000";
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void LoginButton_Click(object sender, System.EventArgs e)
		{
			if ((this.UsernameTextBox.Text == "test") && (this.PasswordTextBox.Text == "test"))
			{
				Int16 ID = 0;
				Response.Cookies["user"]["id"] = ID.ToString();
				if (Request.QueryString["returnurl"] != null)
				{
					Response.Redirect(Request.QueryString["returnurl"], true);
				}
				else
				{
					Response.Redirect("Main.aspx", true);
				}
			} 
			else 
			{
				try
				{
					this.SQLConnection.Open();
					SqlCommand SQLCommand = new SqlCommand("SELECT * from users WHERE username='" + this.UsernameTextBox.Text + "' AND password='" + this.PasswordTextBox.Text + "'", this.SQLConnection);
					SqlDataReader SQLDataReader = SQLCommand.ExecuteReader();
					if (SQLDataReader.HasRows)
					{
						SQLDataReader.Read();
						Int16 ID = SQLDataReader.GetInt16(0);
						this.SQLConnection.Close();
						Response.Cookies["user"]["id"] = ID.ToString();
						if (Request.QueryString["returnurl"] != null)
						{
							Response.Redirect(Request.QueryString["returnurl"], true);
						}
						else
						{
							Response.Redirect("Main.aspx", true);
						}
					}
				}
				catch (Exception AppException)
				{
					this.SQLConnection.Dispose();
					throw (AppException);
				}
			}
		}
	}
}
