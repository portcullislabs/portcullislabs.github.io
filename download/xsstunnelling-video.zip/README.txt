XSS Tunnelling Demonstration Videos

XSS Tunnelling Paper
http://www.portcullis-security.com/uplds/whitepapers/XSSTunnelling.pdf

Download XSS Shell, XSS Tunnel and source codes
http://www.portcullis-security.com/tools/free/xssshell-xsstunnell.zip

Exploited Wordpress Persistent Vulnerability discovered by David Kierznowski
http://michaeldaw.org/md-hacks/wordpress-persistent-xss/







